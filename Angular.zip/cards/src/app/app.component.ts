import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  posts = [
    {
      title: 'Neat Tree',
      imageUrl: 'assets/tree.jpeg',
      username: 'nature',
      content: 'I saw this neat tree today'
    },
    {
      title: 'Snowy mountain',
      imageUrl: 'assets/mountain.jpeg',
      username: 'mountainguy',
      content: 'Nice pic of a snowy mountain'
    },
    {
      title: 'Biking gang shit',
      imageUrl: 'assets/biking.jpeg',
      username: 'biker123',
      content: 'Bike gang went lit today'
    },
    {
      title: 'Biking gang shit',
      imageUrl: 'assets/biking.jpeg',
      username: 'biker123',
      content: 'Bike gang went lit today'
    },
    {
      title: 'Biking gang shit',
      imageUrl: 'assets/biking.jpeg',
      username: 'biker123',
      content: 'Bike gang went lit today'
    },

  ];
}
