import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  name: string | undefined;
  date: string | undefined;
  amount: string | undefined;
  height: string | undefined;
  miles: string | undefined;
  

  getName(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  onDateChange(event: Event): string {
    return (event.target as HTMLInputElement).value;
  }

  onAmountChange(event: Event): string {
    return (event.target as HTMLInputElement).value as string;
  }

  onHeightChange(event: Event): string {
    return (event.target as HTMLInputElement).value as string;
  }

  onMilesChange(event: Event): string {
    return (event.target as HTMLInputElement).value as string;
  }

}
